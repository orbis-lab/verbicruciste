export default class ApiLoader {
    constructor(app, container) {
        this.app = app;
        this.container = container; // Peut être un sélecteur (ex: '#modal') ou un élément DOM

        this.loadAndInit("components/api-loader/index.html")
    }

    // Méthode principale pour charger le HTML et initialiser la modale
    async loadAndInit(htmlUrl) {
        try {
            // 1. Charger le fichier HTML via fetch
            const response = await fetch(htmlUrl);
            if (!response.ok) {
                throw new Error(`Erreur de chargement: ${response.statusText}`);
            }
            const htmlContent = await response.text();

            // 2. Récupérer le conteneur et y injecter le HTML
            const targetContainer = typeof this.container === 'string'
                ? document.querySelector(this.container)
                : this.container;


            if (!targetContainer) {
                throw new Error('Conteneur introuvable dans le DOM');
            }

            targetContainer.innerHTML = htmlContent;

            // 3. Initialiser les écouteurs une fois le contenu présent dans le DOM
            this.initListeners();

        } catch (error) {
            console.error('Erreur lors de l\'initialisation :', error);
        }
    }

    // Méthode privée ou secondaire pour les écouteurs
    initListeners() {


    }

    show() {

        let loader = (typeof this.container === 'string' ? document.querySelector(this.container) : this.container).children[0];

        if (loader) loader.classList.add("active");
    }

    hide() {
        let loader = (typeof this.container === 'string' ? document.querySelector(this.container) : this.container).children[0];

        if (loader) loader.classList.remove("active");
    }

}
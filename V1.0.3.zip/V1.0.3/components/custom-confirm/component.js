export default class CustomConfirm {
    constructor(app, container) {
        this.app = app;
        this.container = container; // Peut être un sélecteur (ex: '#modal') ou un élément DOM

        this.modalEl = null

        this.loadAndInit('./components/custom-confirm/index.html')
    }

    // Méthode principale pour charger le HTML et initialiser la modale
    async loadAndInit(htmlUrl) {
        try {
            // 1. Charger le fichier HTML via fetch
            const response = await fetch(htmlUrl);
            if (!response.ok) {
                throw new Error(`Erreur de chargement: ${response.statusText}`);
            }
            const htmlContent = await response.text();

            // 2. Récupérer le conteneur et y injecter le HTML
            const targetContainer = typeof this.container === 'string'
                ? document.querySelector(this.container)
                : this.container;

            if (!targetContainer) {
                throw new Error('Conteneur introuvable dans le DOM');
            }

            targetContainer.innerHTML = htmlContent;

            // 3. Initialiser les écouteurs une fois le contenu présent dans le DOM
            this.initListeners();

        } catch (error) {
            console.error('Erreur lors de l\'initialisation :', error);
        }
    }

    // Méthode privée ou secondaire pour les écouteurs
    initListeners() {


        this.modalEl = document.getElementById('customConfirmModal');
        const okBtn = document.getElementById('customConfirmOkBtn');
        const cancelBtn = document.getElementById('customConfirmCancelBtn');

        if (okBtn) {
            okBtn.addEventListener('click', () => {
                this.close();
                if (this.resolveCallback) this.resolveCallback(true);
            });
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                this.close();
                if (this.resolveCallback) this.resolveCallback(false);
            });
        }

        if (this.modalEl) {
            this.modalEl.addEventListener('click', (e) => {
                if (e.target === this.modalEl) {
                    this.close();
                    if (this.resolveCallback) this.resolveCallback(false);
                }
            });
        }


    }

    show(message) {
        return new Promise((resolve) => {
            this.resolveCallback = resolve;
            if (!this.modalEl) return resolve(false);

            const msgEl = document.getElementById('customConfirmMessage');
            if (msgEl) msgEl.textContent = message;

            this.modalEl.classList.add('active');
        });
    }

    close() {
        if (this.modalEl) {
            this.modalEl.classList.remove('active');
        }
    }
}


















export default class Toolbar {
    constructor(app, container) {
        this.app = app;
        this.container = container; // Peut être un sélecteur (ex: '#modal') ou un élément DOM

        this.initPromise = this.loadAndInit("components/toolbar/index.html")
    }

    // Méthode principale pour charger le HTML et initialiser la modale
    async loadAndInit(htmlUrl) {
        try {
            // 1. Charger le fichier HTML via fetch
            const response = await fetch(htmlUrl);
            if (!response.ok) {
                throw new Error(`Erreur de chargement: ${response.statusText}`);
            }
            const htmlContent = await response.text();

            // 2. Récupérer le conteneur et y injecter le HTML
            const targetContainer = typeof this.container === 'string'
                ? document.querySelector(this.container)
                : this.container;

            if (!targetContainer) {
                throw new Error('Conteneur introuvable dans le DOM');
            }

            targetContainer.innerHTML = htmlContent;

            // 3. Initialiser les écouteurs une fois le contenu présent dans le DOM
            this.initListeners();

        } catch (error) {
            console.error('Erreur lors de l\'initialisation :', error);
        }
    }

    // Méthode privée ou secondaire pour les écouteurs
    initListeners() {


        const newGridBtn = document.getElementById('newGridBtn');        
        const openGridBtn = document.getElementById('openGridBtn');
        const saveGridBtn = document.getElementById('saveGridBtn');        
        const saveAsGridBtn = document.getElementById('saveAsGridBtn');
        const printGridBtn = document.getElementById('printGridBtn');
        const clearCellBtn = document.getElementById('clearCellBtn');
        const clearGridBtn = document.getElementById('clearGridBtn');
        const settingsGridBtn = document.getElementById('settingsGridBtn');
        const themeAppBtn = document.getElementById('themeAppBtn');
        const helpAppBtn = document.getElementById('helpAppBtn');
        const userAppBtn = document.getElementById('userAppBtn');
       


        newGridBtn.addEventListener('click', (event) => {
            this.app.createGrid();
        });

        openGridBtn.addEventListener('click', (event) => {
            this.app.openLoadModal();
        });

        saveGridBtn.addEventListener('click', (event) => {
            this.app.saveGrid();
        });

        saveAsGridBtn.addEventListener('click', (event) => {
            this.app.state.ui.components.Modals.open("save-as");
        });
        printGridBtn.addEventListener('click', (event) => {
            window.print();
        });

        clearCellBtn.addEventListener('click', (event) => {
            this.app.clearCell();
        });

        clearGridBtn.addEventListener('click', (event) => {
            this.app.clearGrid();
        });

        settingsGridBtn.addEventListener('click', (event) => {
            this.app.state.ui.components.Modals.open("settings")
        });
        
        themeAppBtn.addEventListener('click', (event) => {
            this.app.state.ui.components.Modals.open("theme")
        });

        helpAppBtn.addEventListener('click', (event) => {
            this.app.state.ui.components.Modals.open("help")
        });

        userAppBtn.addEventListener('click', (event) => {
            this.app.state.ui.components.Modals.open("account")
        });

        

    }
}
export default class AuthForm {
    constructor(app, container) {
        this.app = app;
        this.container = container; // Peut être un sélecteur (ex: '#modal') ou un élément DOM

        this.loadAndInit("components/auth-form/index.html")
    }

    // Méthode principale pour charger le HTML et initialiser la modale
    async loadAndInit(htmlUrl) {
        try {
            // 1. Charger le fichier HTML via fetch
            const response = await fetch(htmlUrl);
            if (!response.ok) {
                throw new Error(`Erreur de chargement: ${response.statusText}`);
            }
            const htmlContent = await response.text();

            // 2. Récupérer le conteneur et y injecter le HTML
            const targetContainer = typeof this.container === 'string'
                ? document.querySelector(this.container)
                : this.container;


            if (!targetContainer) {
                throw new Error('Conteneur introuvable dans le DOM');
            }

            targetContainer.innerHTML = htmlContent;

            // 3. Initialiser les écouteurs une fois le contenu présent dans le DOM
            this.initListeners();

        } catch (error) {
            console.error('Erreur lors de l\'initialisation :', error);
        }
    }

    // Méthode privée ou secondaire pour les écouteurs
    initListeners() {

        document.getElementById('tabLoginBtn').addEventListener('click', (event) => {
            this.setTab('login');
        });

        document.getElementById('tabRegisterBtn').addEventListener('click', (event) => {
            this.setTab('register');
        });

        document.getElementById('loginForm').addEventListener('submit', (event) => {
            this.app.handleLogin(event);
        });

        document.getElementById('registerForm').addEventListener('submit', (event) => {
            this.app.handleRegister(event);
        });


    }

    setTab(tab) {

        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        const tabLoginBtn = document.getElementById('tabLoginBtn');
        const tabRegisterBtn = document.getElementById('tabRegisterBtn');


        switch (tab) {
            case 'login':
                loginForm.style.display = 'block';
                registerForm.style.display = 'none';
                tabLoginBtn.classList.add('active');
                tabRegisterBtn.classList.remove('active');
                break;

            case 'register':
                loginForm.style.display = 'none';
                registerForm.style.display = 'block';
                tabRegisterBtn.classList.add('active');
                tabLoginBtn.classList.remove('active');
                break;
        }


    }

    show() {
        document.getElementById('authModal').classList.add('active');
    }

    hide() {
        document.getElementById('authModal').classList.remove('active');
    }

}
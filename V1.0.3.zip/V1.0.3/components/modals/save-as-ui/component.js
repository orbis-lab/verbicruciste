export default class SaveAsUI {
    constructor(app, container, saveAsNAme) {
        this.app = app;
        this.container = container; // Peut être un sélecteur (ex: '#modal') ou un élément DOM

        this.saveAsNAme = saveAsNAme

        this.initPromise = this.loadAndInit("components/modals/save-as-ui/index.html")
    }

    // Méthode principale pour charger le HTML et initialiser 
    async loadAndInit(htmlUrl) {
        try {
            // 1. Charger le fichier HTML via fetch
            const response = await fetch(htmlUrl);
            if (!response.ok) {
                throw new Error(`Erreur de chargement: ${response.statusText}`);
            }
            const htmlContent = await response.text();

            // 2. Récupérer le conteneur et y injecter le HTML
            const targetContainer = typeof this.container === 'string'
                ? document.querySelector(this.container)
                : this.container;

            if (!targetContainer) {
                throw new Error('Conteneur introuvable dans le DOM');
            }

            targetContainer.innerHTML = htmlContent;

            // 3. Initialiser les écouteurs une fois le contenu présent dans le DOM
            this.initListeners();

        } catch (error) {
            console.error('Erreur lors de l\'initialisation du component :', error);
        }
    }

    // Méthode privée ou secondaire pour les écouteurs
    initListeners() {
        
        const saveAsNameInput = document.getElementById("saveAsNameInput")

        saveAsNameInput.value = this.saveAsNAme + " - (Copie)"


        document.getElementById('confirmSaveBtnCloud').addEventListener('click', (event) => {
            this.app.confirmSaveAs('cloud', saveAsNameInput.value);
        });

        document.getElementById('confirmSaveFile').addEventListener('click', (event) => {
            this.app.confirmSaveAs('file', saveAsNameInput.value);
        });

    }

    destroy() {
        const targetContainer = typeof this.container === 'string'
            ? document.querySelector(this.container)
            : this.container;


        targetContainer.innerHTML = "htmlContent";
    }
}
export default class AccountUI {
    constructor(app, container, firstName, lastName, email) {
        this.app = app;
        this.container = container; // Peut être un sélecteur (ex: '#modal') ou un élément DOM

        this.firstName = firstName
        this.lastName = lastName
        this.email = email
        this.fullName = (firstName || lastName) ? `${firstName} ${lastName}`.trim() : "Utilisateur";


        this.colors = this.getColors()

        this.initPromise = this.loadAndInit("components/modals/account-ui/index.html")
    }

    // Méthode principale pour charger le HTML et initialiser 
    async loadAndInit(htmlUrl) {
        try {
            // 1. Charger le fichier HTML via fetch
            const response = await fetch(htmlUrl);
            if (!response.ok) {
                throw new Error(`Erreur de chargement: ${response.statusText}`);
            }
            const htmlContent = await response.text();

            // 2. Récupérer le conteneur et y injecter le HTML
            const targetContainer = typeof this.container === 'string'
                ? document.querySelector(this.container)
                : this.container;

            if (!targetContainer) {
                throw new Error('Conteneur introuvable dans le DOM');
            }

            targetContainer.innerHTML = htmlContent;

            // 3. Initialiser les écouteurs une fois le contenu présent dans le DOM
            this.initListeners();

        } catch (error) {
            console.error('Erreur lors de l\'initialisation du component :', error);
        }
    }

    // Méthode privée ou secondaire pour les écouteurs
    initListeners() {

        const nameModalDisplay = document.getElementById("userNameModalDisplay");
        const emailModalDisplay = document.getElementById("userEmailModalDisplay");
        const avatarDisplay = document.getElementById("userAvatarDisplay");
        const handleLogoutBtn = document.getElementById('handleLogoutBtn');

        nameModalDisplay.textContent = this.fullName;
        emailModalDisplay.textContent = this.email;
        avatarDisplay.textContent = this.getInitials();
        avatarDisplay.style.backgroundColor = this.getBackgroundColor();


        if (handleLogoutBtn) {
            handleLogoutBtn.addEventListener('click', () => {
                this.app.handleLogout();
            });
        }


    }

    getColors() {
        return [
            '#1976d2', '#d32f2f', '#388e3c', '#f57c00',
            '#7b1fa1', '#0097a7', '#c2175b', '#5d4037'
        ];
    }

    getInitials() {
        return `${this.firstName.charAt(0).toUpperCase()}.${this.lastName.charAt(0).toUpperCase()}`
    }

    getBackgroundColor() {
        let hash = 0;
        let str = this.email || this.fullName;

        for (let i = 0; i < str.length; i++) {
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }

        let colorIndex = Math.abs(hash) % this.colors.length;

        return this.colors[colorIndex];
    }

    destroy() {
        const targetContainer = typeof this.container === 'string'
            ? document.querySelector(this.container)
            : this.container;


        targetContainer.innerHTML = "htmlContent";
    }
}
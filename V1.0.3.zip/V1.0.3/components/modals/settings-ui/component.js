export default class SettingsUI {
    constructor(app, container, name, cols, rows) {
        this.app = app;
        this.container = container; // Peut être un sélecteur (ex: '#modal') ou un élément DOM

        this.name = name
        this.cols = cols
        this.rows = rows

        this.initPromise = this.loadAndInit("components/modals/settings-ui/index.html")
    }

    // Méthode principale pour charger le HTML et initialiser 
    async loadAndInit(htmlUrl) {
        try {
            // 1. Charger le fichier HTML via fetch
            const response = await fetch(htmlUrl);
            if (!response.ok) {
                throw new Error(`Erreur de chargement: ${response.statusText}`);
            }
            const htmlContent = await response.text();

            // 2. Récupérer le conteneur et y injecter le HTML
            const targetContainer = typeof this.container === 'string'
                ? document.querySelector(this.container)
                : this.container;

            if (!targetContainer) {
                throw new Error('Conteneur introuvable dans le DOM');
            }

            targetContainer.innerHTML = htmlContent;

            // 3. Initialiser les écouteurs une fois le contenu présent dans le DOM
            this.initListeners();

        } catch (error) {
            console.error('Erreur lors de l\'initialisation du component :', error);
        }
    }

    // Méthode privée ou secondaire pour les écouteurs
    initListeners() {

        const settingName = document.getElementById('settingName')
        const settingCols = document.getElementById('settingCols')
        const settingRows = document.getElementById('settingRows')
        const applySettingsBtn = document.getElementById('applySettingsBtn');

        settingName.value = this.name
        settingCols.value = this.cols;
        settingRows.value = this.rows;


        if (applySettingsBtn) {
            applySettingsBtn.addEventListener('click', () => {
                this.app.applySettings();
            });
        }


        
    }
    destroy() {
        const targetContainer = typeof this.container === 'string'
            ? document.querySelector(this.container)
            : this.container;


        targetContainer.innerHTML = "htmlContent";
    }
}
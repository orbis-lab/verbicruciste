export default class CustomAlert {
    constructor(app, container) {
        this.app = app;
        this.container = container; // Peut être un sélecteur (ex: '#modal') ou un élément DOM

        this.modalEl = null

        this.loadAndInit('./components/custom-alert/index.html')
    }

    // Méthode principale pour charger le HTML et initialiser la modale
    async loadAndInit(htmlUrl) {
        try {
            // 1. Charger le fichier HTML via fetch
            const response = await fetch(htmlUrl);
            if (!response.ok) {
                throw new Error(`Erreur de chargement: ${response.statusText}`);
            }
            const htmlContent = await response.text();

            // 2. Récupérer le conteneur et y injecter le HTML
            const targetContainer = typeof this.container === 'string'
                ? document.querySelector(this.container)
                : this.container;

            if (!targetContainer) {
                throw new Error('Conteneur introuvable dans le DOM');
            }

            targetContainer.innerHTML = htmlContent;

            // 3. Initialiser les écouteurs une fois le contenu présent dans le DOM
            this.initListeners();

        } catch (error) {
            console.error('Erreur lors de l\'initialisation :', error);
        }
    }

    // Méthode privée ou secondaire pour les écouteurs
    initListeners() {


        this.modalEl = document.getElementById('customAlertModal');
        const okBtn = document.getElementById('customAlertOkBtn');

        if (okBtn) {
            okBtn.addEventListener('click', () => this.close());
        }

        if (this.modalEl) {
            this.modalEl.addEventListener('click', (e) => {
                if (e.target === this.modalEl) this.close();
            });
        }


    }

    show(message) {
        if (!this.modalEl) return;
        const msgEl = document.getElementById('customAlertMessage');
        if (msgEl) msgEl.textContent = message;
        this.modalEl.classList.add('active');
    }

    close() {
        if (this.modalEl) {
            this.modalEl.classList.remove('active');
        }
    }
}






